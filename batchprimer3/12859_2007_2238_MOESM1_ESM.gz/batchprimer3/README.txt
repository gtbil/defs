BatchPrimer3 

Copyright (c) 2007, Depatrtment of Plant Sciences, University of California, and 
Genomics and Gene Discorvery Unit, USDA-ARS-WRRC.
Authors: Dr. Frank M. You et al.

***********************************************************************
The BatchPrimer3 web application is developed based on the Primer3 core program, 
Primer3Web AND Primer3Plus. This product itself must include the Primer3 core 
program developed by the Whitehead Institute for Biomedical Research.
***********************************************************************

BatchPrimer3 is a comprehensive web primer design program to develop different types 
of primers in a high-throughput manner. BatchPrimer3 v1.0 implements several types of 
primer designs including generic primers, SSR primers together with SSR detection, and 
SNP genotyping primers (including single-base extension primers, allele-specific 
primers, and tetra-primers for tetra-primer ARMS PCR), as well as DNA sequencing 
primers. DNA sequences in FASTA format can be batch read into the program. The basic 
information of input sequences, as a reference of parameter setting of primer design, can 
be obtained by pre-analysis of sequences. The input sequences can be pre-processed and 
masked to exclude and/or include specific regions, or set targets for different primer 
design purposes as in Primer3Web and primer3Plus. A tab-delimited or Excel-formatted 
primer output also greatly facilitates the subsequent primer-ordering process. 


REQUIREMENTS OF BATCHPRIMER3
Operating system: The software should run in different operating systems, such as 
Solaris, Linux, Mac-OS or Windows. Tests were performed only in Solaris and SuSE 
Linux systems. Some minor modifications are needed for other operation systems. 
Language: Perl interpreter program, Perl 5.8 or above.
HTTP Server: Apache HTTP server.
Perl package: The following Perl packages are needed:
FileHandle
IPC::Open3
Carp
CGI
Socket
GD::Graph::bars
GD::Graph::colour
GD::Text
POSIX 
Email::Valid
Thread

 
INSTALLATION
Here are the installation instructions for Solaris Unix and Linux system.

1. Download site: The application with source code is downloadable at 
http://wheat.pw.usda.gov/demos/Batchprimer3/.

2. Unzip the downloaded file: batchprimer3.tar.gzip
This is a tarred and gzipped file, in which there are two directories, "batchprimer3_cgi-bin" 
and "batchprimer3_htdocs", and a README file for installation instructions.

gunzip batchpriumer3.tar.gzip
tar �xvf batchprimer3.tar

3. Copy the "batchprimer3_cgi-bn" directory to your Apache server "cgi-bin" directory.
(1)	Rename the directory to "batchprimer3",
(2)	Change directory permissions: chmod 777 batchprimer3. 
(3)	Change the access permission of all files in the "batchprimer3" directory: 
chmod 777 *

4. Copy the "batchprimer3_htdocs" directory to your Apache server "htdocs" directory and 
rename the directory to "batchprimer3".

5. Download the Primer3 core program in an executable form or source code for 
compiling at http://primer3.sourceforge.net/releases.php. 
(1)	Copy the executable primer3_core program in the /cgi-bin/batchprimer3/ directory.
(2)	Change the access permission of the primer3_core program to 777: 
chmod 777 primer3_core.

6. In the /cgi-bin/batchprimer3/ directory, you need to correctly set the parameters in two 
programs, batchprimer3.cgi and batchprimer3_report.cgi. Please carefully check the 
header part in these two files.


QUESTIONS AND COMMENTS:
Please send your comments to Dr. Frank M. You, frankyou@pw.usda.gov.

